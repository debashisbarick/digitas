<?php

namespace Drupal\Core\Entity;

/**
 * Provides an interface defining an entity view mode entity type.
 */
interface EntityViewModeInterface extends EntityDisplayModeInterface {

}
