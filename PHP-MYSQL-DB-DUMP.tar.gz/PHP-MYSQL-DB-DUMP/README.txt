• Create multilingual website i. English ii. Hindi
• Default language will be English, if Hindi content is not
added for any content / node then it should show default
English content.
•
For English website it should not be add URL abbreviation
for e.g. example.com/en.. once user switch to Hindi
language then only it will added and it will be like
example.com/hi

=> Downloaded & installed fresh drupal8 and creeted local site called "Digitas"
Datebase Name: "digitas"
Database User name: root
Password : root

=> Enabled Language module
=> Afeter enabling Language module enabled 3 more modules i.e
Content translation
Configuration Translation
Interface Translation

=>Added one more laguage i.e Hindi
=> Under content Language Translation from configuration enabled the translation for content types, blocks, menus, taxonomies ..etc

=> Save
=> Add a node and edit it, We ll find Translation option 
=> As per the requirement once we visit the hindi node of the site language prefix "hi" ll be available.

CUSTOM AJAX FORM
----------------
=> Created module info file 
=> Created Routing file
=> As per PSR standard craeted form class under module_nem/src/Form/formfile
=> Crated basic work flow method i.e buildForm(), ValidateFord(), SubmitForm()
=> Created call back and submit handler for it
=> Collected the data and submitted through ajax.    
